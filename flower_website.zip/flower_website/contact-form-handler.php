<?php
// Проверка, если форма была отправлена методом POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Сбор данных из формы
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['number']);
    $message = htmlspecialchars($_POST['message']);

    // Настройка получателя сообщения (ваш email)
    $to = "your-email@mail.ru";  // Замените на ваш почтовый адрес
    $subject = "New contact form submission";  // Тема письма
    $body = "Name: $name\nEmail: $email\nPhone: $phone\nMessage: $message";  // Текст письма

    // Заголовки письма
    $headers = "From: $email" . "\r\n" .
               "Reply-To: $email" . "\r\n" .
               "X-Mailer: PHP/" . phpversion();

    // Отправка письма
    if (mail($to, $subject, $body, $headers)) {
        echo "Message sent successfully!";
    } else {
        echo "Error in sending message. Please try again.";
    }
}
?>

