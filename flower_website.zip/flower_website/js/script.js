let userBox = document.querySelector('.header .flex .account-box');

document.querySelector('#user-btn').onclick = () =>{
    userBox.classList.toggle('active');
    navbar.classList.remove('active');
}

let navbar = document.querySelector('.header .flex .navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    userBox.classList.remove('active');
}

window.onscroll = () =>{
    userBox.classList.remove('active');
    navbar.classList.remove('active');
}
let favorites = [];
let cart = [];

function addToFavorites(productId) {
    if (!favorites.includes(productId)) {
        favorites.push(productId);
        alert("Товар добавлен в избранное!");
    } else {
        alert("Этот товар уже в избранном!");
    }
}

function addToCart(productId) {
    cart.push(productId);
    alert("Товар добавлен в корзину!");
}
function viewFavorites() {
    const favoritesList = document.getElementById("favorites-list");
    favoritesList.innerHTML = "Избранное: " + favorites.join(", ");
}

function viewCart() {
    const cartList = document.getElementById("cart-list");
    cartList.innerHTML = "Корзина: " + cart.join(", ");
}

