let cart = [];

function addToCart(productName, price) {
    const product = {
        name: productName,
        price: price
    };
    cart.push(product);
    alert(`${productName} has been added to your cart!`);
    updateCartDisplay(); // Обновляем отображение корзины
}

function updateCartDisplay() {
    const cartItemsContainer = document.getElementById('cart-items');
    const totalContainer = document.getElementById('total');
    cartItemsContainer.innerHTML = ''; // Очищаем предыдущие товары
    let total = 0;

    cart.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.innerText = `${item.name} - $${item.price}`;
        cartItemsContainer.appendChild(itemDiv);
        total += item.price;
    });

    totalContainer.innerText = `Total: $${total.toFixed(2)}`;
}
