// Тексты и иконки для разных языков
const translations = {
    en: {
        "aboutTitle": "About Me",
        "bioTitle": "How I Came Up with This Store",
        "bioText": [
            "Opening my flower shop was a dream come true, but it wasn’t without its challenges. The journey started with my passion for flowers and a desire to bring nature’s beauty into people’s homes.",
            "Despite the obstacles, such as managing suppliers and navigating the ups and downs of business, I stayed focused and dedicated to providing high-quality flowers and excellent service."
        ],
        "languageButton": "Русский",
        "languageIcon": "🇬🇧"
    },
    ru: {
        "aboutTitle": "Обо мне",
        "bioTitle": "Как я пришел к этому магазину",
        "bioText": [
            "Открытие моего цветочного магазина было мечтой, но не без трудностей. Путь начался с моей страсти к цветам и желания принести красоту природы в дома людей.",
            "Несмотря на трудности, такие как управление поставками и сложности бизнеса, я остался сосредоточенным и преданным делу предоставления высококачественных цветов и отличного сервиса."
        ],
        "languageButton": "English",
        "languageIcon": "🇷🇺"
    }
};

// Функция для переключения языка
document.getElementById('language-toggle').addEventListener('click', function() {
    let currentLang = document.documentElement.lang;

    // Определяем следующий язык
    let newLang = (currentLang === 'en') ? 'ru' : 'en';

    // Обновляем язык страницы
    document.documentElement.lang = newLang;

    // Обновляем тексты на странице
    document.querySelector('h2').innerText = translations[newLang].aboutTitle;
    document.querySelector('.bio h3').innerText = translations[newLang].bioTitle;
    const bioParagraphs = document.querySelectorAll('.bio p');
    bioParagraphs[0].innerText = translations[newLang].bioText[0];
    bioParagraphs[1].innerText = translations[newLang].bioText[1];

    // Меняем текст на кнопке и иконку
    document.getElementById('language-toggle').querySelector('.language-text').innerText = translations[newLang].languageButton;
    document.getElementById('language-toggle').querySelector('.language-icon').innerText = translations[newLang].languageIcon;
});
