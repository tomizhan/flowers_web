<?php
// submit_registration.php

// Получаем данные из формы
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];

// Проверка соответствия паролей
if ($password !== $confirm_password) {
    echo "Пароли не совпадают!";
    exit;
}

// Хеширование пароля перед сохранением
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Подключение к базе данных
$connection = new mysqli('localhost', 'root', '', 'your_database');

// Проверка на ошибки подключения
if ($connection->connect_error) {
    die("Ошибка подключения: " . $connection->connect_error);
}

// Запрос на вставку данных пользователя
$sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";

// Выполнение запроса и проверка
if ($connection->query($sql) === TRUE) {
    echo "Регистрация успешна!";
} else {
    echo "Ошибка: " . $sql . "<br>" . $connection->error;
}

// Закрытие соединения
$connection->close();
?>
