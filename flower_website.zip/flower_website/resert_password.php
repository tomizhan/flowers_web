<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Reset Password</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
    <h2>Reset Password</h2>
  </div>

  <?php
    if (isset($_GET['token'])) {
        $token = $_GET['token'];

        // Проверка токена в базе данных
        $stmt = $db->prepare("SELECT * FROM users WHERE reset_token=? LIMIT 1");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            // Форма для нового пароля
            echo '
                <form method="post" action="reset_password.php?token=' . $token . '">
                    <div class="input-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" required>
                    </div>
                    <div class="input-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" required>
                    </div>
                    <div class="input-group">
                        <button type="submit" class="btn" name="change_password">Change Password</button>
                    </div>
                </form>
            ';
        } else {
            echo "Invalid or expired token.";
        }
    }

    if (isset($_POST['change_password'])) {
        $new_password = mysqli_real_escape_string($db, $_POST['new_password']);
        $confirm_password = mysqli_real_escape_string($db, $_POST['confirm_password']);

        if ($new_password != $confirm_password) {
            array_push($errors, "Passwords do not match.");
        } else {
            // Обновление пароля в базе данных
            $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE users SET password=?, reset_token=NULL WHERE reset_token=?");
            $stmt->bind_param("ss", $new_password_hashed, $token);
            if ($stmt->execute()) {
                $_SESSION['success'] = "Password updated successfully!";
                header("location: login.php");
            } else {
                array_push($errors, "Failed to update password. Please try again.");
            }
        }
    }
  ?>

</body>
</html>
