<?php 
require_once($_SERVER['DOCUMENT_ROOT'] . '/smartbasket/php/phpmailer/phpmailer.php');
require_once($_SERVER['DOCUMENT_ROOT'] . '/smartbasket/php/phpmailer/smtp.php');

const HOST = 'smtp.mail.ru';
const LOGIN = 'aktoty1909@mail.ru';
const PASS = 'wpKVwqAP5Af26SCguYEJ';
const PORT = 587;

const SENDER = 'aktoty1909@mail.ru'; // Ваш email
const CATCHER = 'zereshhhhkaaa@mail.ru'; // Получатель
const SUBJECT = 'Заявка с сайта';
const CHARSET = 'UTF-8';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Печать данных для отладки
    var_dump($_POST);

    // Проверка на пустые данные
    if (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['message'])) {
        echo "Заполните все поля!";
        exit;
    }

    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    $mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->isSMTP();
    $mail->Host = HOST;
    $mail->SMTPAuth = true;
    $mail->Username = LOGIN;
    $mail->Password = PASS;
    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS; // Используйте SSL, если используете порт 465
    $mail->Port = PORT;

    $mail->setFrom(SENDER, 'Website');
    $mail->addAddress(CATCHER);
    $mail->Subject = SUBJECT;
    $mail->CharSet = CHARSET;
    $mail->Body = "Имя: $name\nEmail: $email\nСообщение: $message";

    // Включите отладку для выявления ошибок
    $mail->SMTPDebug = 2;

    if ($mail->send()) {
        echo "Сообщение отправлено успешно!";
    } else {
        echo "Ошибка при отправке сообщения: {$mail->ErrorInfo}";
    }
}

?>
